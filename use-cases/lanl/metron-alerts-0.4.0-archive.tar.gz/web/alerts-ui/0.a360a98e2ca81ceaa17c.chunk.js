/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * License); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 webpackJsonp([0,8],{oW7D:function(t,e,o){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var n=o("3j3K"),_=o("m/+H"),i=o("5oXY"),r=o("2Je8"),a=o("NVOs"),s=o("fAE3"),u=o("I/bk"),l=o("ssQG"),c=o("0/Fd");o.d(e,"SavedSearchesModuleNgFactory",function(){return d});var h=this&&this.__extends||function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var o in e)e.hasOwnProperty(o)&&(t[o]=e[o])};return function(e,o){function n(){this.constructor=e}t(e,o),e.prototype=null===o?Object.create(o):(n.prototype=o.prototype,new n)}}(),p=function(t){function e(e){return t.call(this,e,[l.a],[])||this}return h(e,t),Object.defineProperty(e.prototype,"_NgLocalization_7",{get:function(){return null==this.__NgLocalization_7&&(this.__NgLocalization_7=new r.a(this.parent.get(n.c))),this.__NgLocalization_7},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"_ɵi_8",{get:function(){return null==this.__ɵi_8&&(this.__ɵi_8=new a.a),this.__ɵi_8},enumerable:!0,configurable:!0}),e.prototype.createInternal=function(){return this._RouterModule_0=new i.q(this.parent.get(i.r,null),this.parent.get(i.j,null)),this._CommonModule_1=new r.b,this._ɵba_2=new a.b,this._FormsModule_3=new a.c,this._SharedModule_4=new s.a,this._CollapseModule_5=new u.a,this._SavedSearchesModule_6=new _.a,this._ROUTES_9=[[{path:"saved-searches",component:c.a,outlet:"dialog"}]],this._SavedSearchesModule_6},e.prototype.getInternal=function(t,e){return t===i.q?this._RouterModule_0:t===r.b?this._CommonModule_1:t===a.b?this._ɵba_2:t===a.c?this._FormsModule_3:t===s.a?this._SharedModule_4:t===u.a?this._CollapseModule_5:t===_.a?this._SavedSearchesModule_6:t===r.g?this._NgLocalization_7:t===a.a?this._ɵi_8:t===i.u?this._ROUTES_9:e},e.prototype.destroyInternal=function(){},e}(n.B),d=new n.C(p,_.a)}});
