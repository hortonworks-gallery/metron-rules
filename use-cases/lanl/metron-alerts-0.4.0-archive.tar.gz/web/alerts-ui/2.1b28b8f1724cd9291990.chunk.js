/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * License); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 webpackJsonp([2,8],{Tu2i:function(t,e,o){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var n=o("3j3K"),i=o("Rgxn"),_=o("5oXY"),r=o("2Je8"),a=o("NVOs"),s=o("fAE3"),u=o("louU"),l=o("eMXk"),h=o("+3am"),c=o("+DBQ"),p=o("NT3J"),d=o("I/bk"),f=o("nBa3"),M=o("fzCf"),g=o("Fzro"),w=o("L9Xm"),b=o("4o/t");o.d(e,"AlertsListModuleNgFactory",function(){return m});var y=this&&this.__extends||function(){var t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var o in e)e.hasOwnProperty(o)&&(t[o]=e[o])};return function(e,o){function n(){this.constructor=e}t(e,o),e.prototype=null===o?Object.create(o):(n.prototype=o.prototype,new n)}}(),S=function(t){function e(e){return t.call(this,e,[M.a],[])||this}return y(e,t),Object.defineProperty(e.prototype,"_NgLocalization_12",{get:function(){return null==this.__NgLocalization_12&&(this.__NgLocalization_12=new r.a(this.parent.get(n.c))),this.__NgLocalization_12},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"_ɵi_13",{get:function(){return null==this.__ɵi_13&&(this.__ɵi_13=new a.a),this.__ɵi_13},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"_AlertService_15",{get:function(){return null==this.__AlertService_15&&(this.__AlertService_15=new f.a(this.parent.get(g.k),this.parent.get(w.a))),this.__AlertService_15},enumerable:!0,configurable:!0}),e.prototype.createInternal=function(){return this._RouterModule_0=new _.q(this.parent.get(_.r,null),this.parent.get(_.j,null)),this._CommonModule_1=new r.b,this._ɵba_2=new a.b,this._FormsModule_3=new a.c,this._SharedModule_4=new s.a,this._SwitchModule_5=new u.a,this._ConfigureRowsModule_6=new l.a,this._MetronSorterModule_7=new h.a,this._MetronTablePaginationModule_8=new c.a,this._ListGroupModule_9=new p.a,this._CollapseModule_10=new d.a,this._AlertsListModule_11=new i.a,this._ROUTES_14=[[{path:"",component:b.a}]],this._AlertsListModule_11},e.prototype.getInternal=function(t,e){return t===_.q?this._RouterModule_0:t===r.b?this._CommonModule_1:t===a.b?this._ɵba_2:t===a.c?this._FormsModule_3:t===s.a?this._SharedModule_4:t===u.a?this._SwitchModule_5:t===l.a?this._ConfigureRowsModule_6:t===h.a?this._MetronSorterModule_7:t===c.a?this._MetronTablePaginationModule_8:t===p.a?this._ListGroupModule_9:t===d.a?this._CollapseModule_10:t===i.a?this._AlertsListModule_11:t===r.g?this._NgLocalization_12:t===a.a?this._ɵi_13:t===_.u?this._ROUTES_14:t===f.a?this._AlertService_15:e},e.prototype.destroyInternal=function(){},e}(n.B),m=new n.C(S,i.a)}});
